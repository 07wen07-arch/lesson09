# 独立研究

## 1 MapReduce并行k均值

普通k均值每一轮都要为所有样本寻找最近中心，并重新计算各簇均值。数据量大时，单机的内存、计算和读取时间会成为瓶颈。

可以把数据分块交给多个工作节点。Map阶段根据当前中心为每条样本确定簇，输出簇编号及特征向量；局部聚合先计算各簇的向量和、人数；Reduce阶段汇总各节点的和与人数，相除得到新中心。再把新中心发回节点，进行下一轮。

它解决的是大数据下的计算分摊和数据处理规模问题，并不会自动解决量纲不一致、k选择错误或非球形簇问题。每一轮仍要同步中心并进行通信，200条课程数据通常没有必要使用分布式系统。

这是根据分配—更新步骤作出的并行化说明。参考Apache Spark的分布式KMeans实现介绍：[Spark聚类文档](https://spark.apache.org/docs/latest/mllib-clustering.html#k-means)。本作业没有声称实际部署MapReduce集群。

## 2 环形数据与DBSCAN

使用 `make_circles(n_samples=400, factor=0.45, noise=0.025, random_state=42)` 另行生成内外两环的玩具数据。它只用于研究，不替代银行数据。

KMeans设k=2；DBSCAN设 `eps=0.16, min_samples=5`。用生成器给出的内外环标记计算ARI，KMeans为-0.0025，DBSCAN为1.0000，DBSCAN没有标出噪声点。ARI接近0表示与内外环划分的一致性接近随机水平，1表示完全一致（不受编号交换影响）。

![环形数据对比](outputs/04_rings.png)

图中KMeans近似按左右切分，把两个环各切成两部分，因为它按到中心的距离划分空间。DBSCAN按密度连接邻近样本，在这组参数下找到了内环与外环。不过这只是该玩具数据上的结果，不能据此断定DBSCAN对任何数据都更好；噪声、密度差异和参数都会影响结果。

参考：[scikit-learn聚类算法对比示例](https://scikit-learn.org/stable/auto_examples/cluster/plot_cluster_comparison.html)。

## 3 轮廓系数

对一个样本，a是它与同簇其他样本的平均距离；b是它到其他各簇平均距离的最小值。该样本的轮廓系数为 `(b-a)/max(a,b)`，总体指标是所有样本的平均。

因为a、b非负，差值的绝对值不超过二者最大值，所以结果在[-1,1]之间。接近1表示本簇内近、与邻簇远；接近0表示边界较模糊；负值表示它平均而言可能更接近别的簇。单样本簇按实现约定记为0；至少需要两个簇，且不能每个样本各自一簇。

本次四簇标准化结果的平均轮廓系数为0.2275307781。独立用两两距离重新计算，得到同一数值。它不是“22.75%的分类准确率”，而是簇内紧密程度和簇间分离程度的综合量。本次k=7时为0.2642，高于四簇方案，具体比较见report.md。

来源：[scikit-learn轮廓系数定义](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.silhouette_score.html)。
