"""第9课四簇版作业。运行 python main.py 重新生成全部实验结果。"""
from pathlib import Path
import os
import json
import hashlib

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mplconfig'))
os.environ.setdefault('OMP_NUM_THREADS', '1')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from sklearn.cluster import KMeans, DBSCAN
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sklearn.datasets import make_circles
from scipy.optimize import linear_sum_assignment
from threadpoolctl import threadpool_limits

FEATURES = ['balance', 'avg_monthly_spend', 'product_count', 'overdue_count']
LABELS = ['余额（元）', '月均消费（元）', '产品数', '逾期次数']
SOURCE_HASH = 'b82ef3124080469b7f208e246f08b6de66bc2a057e0aa84d6eea481716d578da'
OUT = ROOT / 'outputs'
COLORS = ['#277da1', '#f8961e', '#43aa8b', '#b56576']


def load_data():
    """只读原始文件，缺失填补仅在内存中的聚类特征上进行。"""
    path = ROOT / 'data' / 'bank_customers.csv'
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != SOURCE_HASH:
        raise ValueError('原始数据哈希与已核验课程文件不一致，请检查数据来源')
    df = pd.read_csv(path)
    if len(df) != 200 or not df['customer_id'].is_unique:
        raise ValueError('应为200位不重复客户')
    return df


def fit_clusters(df, features=FEATURES, scale=True, seed=42, k=4):
    values = SimpleImputer(strategy='median').fit_transform(df[features])
    if not np.isfinite(values).all():
        raise ValueError('特征必须是有限数值')
    scaler = StandardScaler() if scale else None
    x = scaler.fit_transform(values) if scale else values.copy()
    model = KMeans(n_clusters=k, random_state=seed, n_init=10).fit(x)
    # 展示编号按原始量纲下的平均余额升序排列，编号本身不代表优劣。
    centers = scaler.inverse_transform(model.cluster_centers_) if scale else model.cluster_centers_
    order = np.argsort(centers[:, 0])
    mapping = np.empty(k, dtype=int)
    mapping[order] = np.arange(k)
    labels = mapping[model.labels_]
    prepared = pd.DataFrame(values, columns=features, index=df.index)
    profile = prepared.assign(cluster=labels).groupby('cluster').mean()
    profile.insert(0, 'count', np.bincount(labels, minlength=k))
    profile.insert(1, 'share', profile['count'] / len(df))
    return {'labels': labels, 'profile': profile, 'x': x, 'values': values,
            'centers': centers[order], 'inertia': float(model.inertia_),
            'silhouette': float(silhouette_score(x, labels))}


def matched_changes(reference, other, k=4):
    """用最大重叠匹配簇标签，防止标签交换导致虚假的变化人数。"""
    contingency = np.zeros((k, k), dtype=int)
    np.add.at(contingency, (reference, other), 1)
    rows, cols = linear_sum_assignment(-contingency)
    mapping = dict(zip(cols, rows))
    aligned = np.array([mapping[int(label)] for label in other])
    return int(np.count_nonzero(reference != aligned)), aligned


def configure_plots():
    installed = {f.name for f in font_manager.fontManager.ttflist}
    font = next((f for f in ['Microsoft YaHei', 'SimHei', 'Noto Sans CJK SC'] if f in installed), None)
    if not font:
        raise RuntimeError('缺少中文字体，请安装微软雅黑、黑体或Noto Sans CJK SC')
    plt.rcParams.update({'font.family': font, 'axes.unicode_minus': False,
                         'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
    return font


def savefig(fig, name):
    fig.savefig(OUT / name, dpi=150, bbox_inches='tight')
    plt.close(fig)


def main():
    OUT.mkdir(exist_ok=True)
    font = configure_plots()
    df = load_data()
    baseline = fit_clusters(df)
    raw = fit_clusters(df, scale=False)
    extended = fit_clusters(df, FEATURES + ['account_age_months'])
    runs = {'baseline': baseline, 'unscaled': raw, 'extended': extended}
    for name, result in runs.items():
        result['profile'].to_csv(OUT / f'{name}_profiles.csv', encoding='utf-8-sig')
    # 标签写入结果副本，绝不回写 data/ 原始CSV。
    assigned = df.copy()
    for name, result in runs.items():
        assigned[f'cluster_{name}'] = result['labels']
    assigned.to_csv(OUT / 'customer_clusters.csv', index=False, encoding='utf-8-sig')

    choices = []
    for k in range(1, 10):
        model = KMeans(n_clusters=k, random_state=42, n_init=10).fit(baseline['x'])
        choices.append({'k': k, 'sse': float(model.inertia_),
                        'silhouette': float(silhouette_score(baseline['x'], model.labels_)) if k > 1 else None})
    scores = pd.DataFrame(choices)
    scores.to_csv(OUT / 'k_selection.csv', index=False, encoding='utf-8-sig')
    # 首尾连线距离仅作肘点候选提示，不声称存在数学唯一的最佳k。
    normalized_sse = (scores.sse - scores.sse.iloc[-1]) / (scores.sse.iloc[0] - scores.sse.iloc[-1])
    distances = 1 - np.linspace(0, 1, 9) - normalized_sse.to_numpy()
    elbow = int(scores.iloc[np.argmax(distances)].k)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), layout='constrained')
    axes[0].plot(scores.k, scores.sse, 'o-', color=COLORS[0])
    axes[0].axvline(elbow, linestyle='--', color=COLORS[1], label=f'肘点候选 k={elbow}')
    axes[0].axvline(4, linestyle=':', color=COLORS[3], label='作业画像 k=4')
    axes[0].set(title='肘部法：标准化四特征', xlabel='簇数 k', ylabel='簇内平方和 SSE')
    axes[0].legend()
    axes[1].plot(scores.k[1:], scores.silhouette[1:], 'o-', color=COLORS[2])
    axes[1].set(title='轮廓系数：辅助判断', xlabel='簇数 k', ylabel='平均轮廓系数')
    for ax in axes:
        ax.set_xticks(range(1, 10)); ax.grid(alpha=.18)
    savefig(fig, '01_elbow.png')

    fig, axes = plt.subplots(2, 2, figsize=(11, 7), layout='constrained')
    for ax, feature, title in zip(axes.flat, FEATURES, LABELS):
        means = baseline['profile'][feature]
        bars = ax.bar([f'客群{i}' for i in range(4)], means, color=COLORS)
        ax.bar_label(bars, fmt='%.2f', padding=3, fontsize=9)
        ax.set_title(title); ax.margins(y=.2)
    fig.suptitle('四类客户画像：填补缺失值后的原始量纲均值')
    savefig(fig, '02_profiles.png')

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6), layout='constrained')
    for ax, (name, result), title in zip(axes, runs.items(), ['标准化四特征', '不标准化四特征', '加入开户月数并标准化']):
        for c in range(4):
            mask = result['labels'] == c
            ax.scatter(result['values'][mask, 0], result['values'][mask, 1], s=24,
                       color=COLORS[c], alpha=.75, label=f'群{c}：{mask.sum()}人')
        ax.set(title=title, xlabel='余额（元）', ylabel='月均消费（元）')
        ax.legend(fontsize=8); ax.ticklabel_format(axis='both', style='sci', scilimits=(0, 0))
    fig.suptitle('二维投影对比（同号不保证同一群；坐标仅展示四/五维聚类结果）')
    savefig(fig, '03_scatter_comparison.png')

    stability = []
    for seed in [42, 7, 2026]:
        run = fit_clusters(df, seed=seed)
        changed, aligned = matched_changes(baseline['labels'], run['labels'])
        p = pd.DataFrame(run['values'], columns=FEATURES).assign(cluster=aligned).groupby('cluster').mean()
        p.insert(0, 'count', np.bincount(aligned, minlength=4))
        p.to_csv(OUT / f'seed_{seed}_profiles_matched.csv', encoding='utf-8-sig')
        stability.append({'seed': seed, 'sse': run['inertia'], 'silhouette': run['silhouette'],
                          'ari_vs_42': float(adjusted_rand_score(baseline['labels'], run['labels'])),
                          'changed_after_matching': changed})
    pd.DataFrame(stability).to_csv(OUT / 'stability.csv', index=False, encoding='utf-8-sig')

    # 独立研究：明确标记为另行生成的玩具数据，不替代银行课程数据。
    rings, truth = make_circles(n_samples=400, factor=.45, noise=.025, random_state=42)
    ring_km = KMeans(n_clusters=2, random_state=42, n_init=10).fit_predict(rings)
    ring_db = DBSCAN(eps=.16, min_samples=5).fit_predict(rings)
    pd.DataFrame({'x': rings[:, 0], 'y': rings[:, 1], 'ring': truth, 'kmeans': ring_km, 'dbscan': ring_db}).to_csv(
        OUT / 'synthetic_rings.csv', index=False)
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), layout='constrained')
    for ax, labels, title in zip(axes, [truth, ring_km, ring_db], ['玩具数据：内外环', 'KMeans：k=2', 'DBSCAN：eps=0.16']):
        ax.scatter(rings[:, 0], rings[:, 1], c=labels, cmap='Set2', s=12)
        ax.set(title=title, xlabel='x', ylabel='y', aspect='equal')
    savefig(fig, '04_rings.png')

    summary = {
        'source_sha256': SOURCE_HASH, 'rows': len(df), 'features': FEATURES, 'font': font,
        'missing_values': {k: int(v) for k, v in df.isna().sum().items()},
        'medians': {k: float(v) for k, v in df[FEATURES + ['account_age_months']].median().items()},
        'baseline': {'counts': baseline['profile']['count'].tolist(), 'sse': baseline['inertia'], 'silhouette': baseline['silhouette']},
        'elbow_candidate': elbow, 'best_silhouette_k': int(scores.loc[scores.silhouette.idxmax(), 'k']),
        'unscaled': {'counts': raw['profile']['count'].tolist(), 'ari_vs_baseline': float(adjusted_rand_score(baseline['labels'], raw['labels']))},
        'extended': {'counts': extended['profile']['count'].tolist(), 'ari_vs_baseline': float(adjusted_rand_score(baseline['labels'], extended['labels'])),
                     'changed_after_matching': matched_changes(baseline['labels'], extended['labels'])[0]},
        'stability': stability,
        'rings': {'kmeans_ari': float(adjusted_rand_score(truth, ring_km)), 'dbscan_ari': float(adjusted_rand_score(truth, ring_db)),
                  'dbscan_noise': int(np.sum(ring_db == -1))}}
    (OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print('\n四簇画像：\n', baseline['profile'].round(3).to_string())
    print('\n加入开户月数：\n', extended['profile'].round(3).to_string())
    print('\n不标准化：\n', raw['profile'].round(3).to_string())
    print('\n选k：\n', scores.round(4).to_string(index=False))


if __name__ == '__main__':
    with threadpool_limits(limits=1):
        main()
