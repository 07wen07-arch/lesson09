# 第9课客户聚类作业

按雨课堂截图、作业单和实践指南的“四簇版”要求完成。原始数据为200位银行客户，选用余额、月均消费、产品数和逾期次数四个特征。

## 查看结果

- `progress.md`：进度报告，也用于雨课堂第1题作答。
- `report.md`：完整分析，包含四个中文客群名称、均值画像和业务建议。
- `research.md`：三项选做研究。
- `ai_usage.md`：实际指令和辅助范围。
- `outputs/`：图表、逐客户分群结果、各项实验统计和验证记录。
- `data/bank_customers.csv`：课程原始数据，保持原字节不变。

## 运行

建议使用Python 3.12。在本文件夹运行：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe verify.py
```

本机已经准备独立环境，可直接使用：

```powershell
& 'D:\ChatGPT工作区\作业\.lesson09-runtime\Scripts\python.exe' main.py
& 'D:\ChatGPT工作区\作业\.lesson09-runtime\Scripts\python.exe' verify.py
```

`main.py`重新生成图表和数值结果；修改数据或参数后，需根据新结果同步更新三个文字报告。脚本不覆盖人工修改的报告。

## 方法说明

先对所选数值特征用中位数填补缺失值，然后标准化，运行 `KMeans(n_clusters=4, random_state=42, n_init=10)`。聚类是对这200位客户的描述性分析，不是违约预测，不划分训练/测试集，也不使用 `is_default`、`risk_level` 或 `customer_id` 作为特征。

簇展示编号按平均余额从低到高排列；比较不同实验时用最大重叠匹配消除编号交换，并用ARI衡量分群一致性。原始量纲和标准化量纲的SSE不能直接比较。

## 提交

新建独立GitHub/Gitee仓库 `lesson09-cluster`，上传本目录内的代码、依赖说明、数据、报告及 `outputs/`。不要上传 `.venv`、`.mplconfig` 或 `__pycache__`。雨课堂第1题填写 `progress.md` 内容，第2题填写实际远程仓库地址。本目录准备好不代表已经完成GitHub上传或雨课堂交卷。

## 课程依据与版本差异

- [实践指南九](https://aip-2026f.dev-learn-hub.me/assets/handouts/aip-student-guide-9.docx)：三步复现、加开户月数、三种子稳定性、二维投影和三项研究。
- [作业要求九](https://aip-2026f.dev-learn-hub.me/assets/handouts/aip-homework-9.docx)：四簇验收、独立仓库和AI记录。
- [进度报告模板](https://aip-2026f.dev-learn-hub.me/assets/handouts/aip-progress-report-9.docx)。

当前网页演示已使用300行商场模拟数据和三簇案例，与上述附件及雨课堂截图不同。本项目选择与截图一致的200行银行数据四簇版，不套用三簇演示的125/125/50结果。

原始数据来源：用户桌面已有的 `bank_customers.csv`，复制到本项目后验证SHA256相同：

```text
b82ef3124080469b7f208e246f08b6de66bc2a057e0aa84d6eea481716d578da
```
