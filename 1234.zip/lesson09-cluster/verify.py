"""读取已生成结果，以独立公式核对SSE与轮廓系数，不改原始数据。"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from main import ROOT, FEATURES, load_data, fit_clusters, matched_changes
from threadpoolctl import threadpool_limits


def verify():
    source = load_data()
    out = ROOT / 'outputs'
    saved = pd.read_csv(out / 'customer_clusters.csv')
    summary = json.loads((out / 'summary.json').read_text(encoding='utf-8'))
    assert len(saved) == len(source) == 200
    pd.testing.assert_frame_equal(source, saved[source.columns])
    labels = saved.cluster_baseline.to_numpy()
    assert set(labels) == {0, 1, 2, 3}
    x = source[FEATURES].fillna(source[FEATURES].median()).to_numpy()
    x = (x - x.mean(axis=0)) / x.std(axis=0)
    manual_sse = sum(float(((x[labels == c] - x[labels == c].mean(axis=0)) ** 2).sum()) for c in range(4))
    assert np.isclose(manual_sse, summary['baseline']['sse'])
    # 用两两距离直接计算每个样本的a和b，不调用silhouette_score。
    distances = cdist(x, x)
    coefficients = []
    for i, c in enumerate(labels):
        same = labels == c
        if same.sum() == 1:
            coefficients.append(0.0)
            continue
        a = distances[i, same].sum() / (same.sum() - 1)
        b = min(distances[i, labels == other].mean() for other in range(4) if other != c)
        coefficients.append((b - a) / max(a, b) if max(a, b) else 0.0)
    assert np.isclose(np.mean(coefficients), summary['baseline']['silhouette'])
    # 只交换编号，不应被识别为客户换群。
    assert matched_changes(labels, (labels + 1) % 4)[0] == 0
    unit_changed = source.copy()
    unit_changed['balance'] *= 10000
    run = fit_clusters(unit_changed)
    assert matched_changes(labels, run['labels'])[0] == 0
    for png in ['01_elbow.png', '02_profiles.png', '03_scatter_comparison.png', '04_rings.png']:
        assert (out / png).stat().st_size > 1000
    checks = ['原始数据哈希和200行逐列一致', '四簇覆盖全部客户', '独立公式核对SSE',
              '独立距离计算核对轮廓系数', '标签交换不产生伪变化', '改变余额单位后标准化分群一致', '四张图像文件存在']
    result = {'status': 'PASS', 'checks': checks, 'manual_sse': manual_sse,
              'manual_silhouette': float(np.mean(coefficients))}
    (out / 'validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    with threadpool_limits(limits=1):
        verify()
